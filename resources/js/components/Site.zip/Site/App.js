import React from 'react';
import Search from './Search/Search';


class App extends React.Component {

      // Map over this.state.mobiles and render a mobiles component for each phone object
      render() {
        // const { phones } = this.state
        return (
          <div >
              <Search/>
          </div>
        );
      }
    }


  export default App;

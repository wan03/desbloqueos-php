import React from 'react';

class Search extends React.Component {







      // Map over this.state.mobiles and render a mobiles component for each phone object
      render() {
        // const { phones } = this.state
        return (
          <div >
          <h1>SEARCH PAGE</h1>
          </div>
        );
      }
    }


  export default Search;
